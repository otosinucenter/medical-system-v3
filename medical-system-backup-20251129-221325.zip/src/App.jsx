import React, { useState, useEffect } from 'react';
import Login from './Login';
import MedicalSystem from './MedicalSystem';

export default function App() {
    const [user, setUser] = useState(null);

    // Efecto para verificar si hay una sesión guardada (opcional, por ahora no persistente)
    useEffect(() => {
        const savedUser = localStorage.getItem('medical_system_user');
        if (savedUser) {
            setUser(JSON.parse(savedUser));
        }
    }, []);

    const handleLogin = (userData) => {
        setUser(userData);
        localStorage.setItem('medical_system_user', JSON.stringify(userData));
    };

    const handleLogout = () => {
        setUser(null);
        localStorage.removeItem('medical_system_user');
    };

    if (!user) {
        return <Login onLogin={handleLogin} />;
    }

    return <MedicalSystem user={user} onLogout={handleLogout} />;
}
